# AI_AGENT_CONTEXT

## 1. System Overview & Stack
- Language: Python (Anki addon runtime).
- UI Framework: Qt widgets qua `aqt.qt` (`QDialog`, `QComboBox`, `QPlainTextEdit`, `QMessageBox`, ...).
- Anki APIs cốt lõi:
  - `aqt.mw` để truy cập collection hiện tại, progress, checkpoint, reset UI.
  - `mw.col.models`, `mw.col.decks`, `mw.col.db`, `mw.col.new_note`, `mw.col.add_note`, `mw.col.update_note` cho CRUD note/deck.
- Media/network stack: `urllib.request` (download URL), `shutil` (copy file local), `uuid` (tạo tên media unique), regex cho legacy `[media:...]`.
- i18n: `i18n.py` với `_t(key, **kwargs)` và locale JSON (`locales/en.json`, `locales/vi.json`).
- User config persistence: `user_config.json` lưu `media_fields`, `lang`, và `presets` (preset thao tác nhanh).
- Entry point: `__init__.py`.
  - Đăng ký menu `AnkiVN` -> action `🚀 JSON Bulk Importer - from AnkiVN with ❤️`.
  - `show_dialog()` gọi `load_lang_from_config()` rồi lazy import `BulkCardCreatorDialog`.

## 2. Module Map
- `core.py`
  - `create_cards_logic(...)`: luồng chính tạo/cập nhật note, xử lý Smart Sync theo `match_field`, xử lý meta keys, tags, deck move, warning.
  - `create_new_model(...)`: tạo Note Type mới từ sample card nếu chưa tồn tại.
  - `_note_field_str(...)`: ép kiểu mọi field về string an toàn cho Anki note fields.
- `media.py`
  - `smart_download_media(...)`: tải/copy media theo field mapping (`image`/`audio`), suy luận extension theo `Content-Type`, trả về tag Anki (`<img ...>` hoặc `[sound:...]`).
  - `resolve_media_in_text(...)`: hỗ trợ legacy pattern `[media:...]` trong text fields.
- `i18n.py`
  - Nạp ngôn ngữ từ config, đổi ngôn ngữ và lưu lại `user_config.json`.
  - `_t(...)` là API dịch duy nhất được dùng xuyên suốt UI/core messages.
- `config.py`
  - `_get_config()`, `_save_config()` cho persistence JSON.
  - `get_media_mappings(note_type_name)` cho media field mapping.
  - `get_presets()` và `save_preset(name, preset_data)` cho preset.
  - `get_history_dir()` và `save_batch_history(record)` cho lưu lịch sử batch ra file JSON.
- `gui/`
  - `main_dialog.py`: dialog chính, validate JSON, chọn note type/deck/smart sync, quản lý preset Save/Load, có nút Sinh GUID, có nút "📌 Add Deck into JSON" để bulk thêm `__deck__` vào cards, có nút mở History folder, gọi `create_cards_logic`, có tùy chọn ghi `__guid__` trở lại JSON sau batch; xử lý history dialog với nút "Open Folder History" và "Close", và có nút Help mở hướng dẫn song ngữ.
  - `help_dialog.py`: dialog trợ giúp riêng, dùng `QTabWidget` với tab English / Tiếng Việt, mô tả ngắn gọn toàn bộ workflow và từng tính năng chính.
  - `table_dialog.py`: xem/chỉnh JSON dạng bảng, paste TSV, pre-fetch media; Toggle Preview Mode để xem HTML render (QTextBrowser) hoặc edit text; Click cell trong Preview Mode hiển thị HTML preview phía dưới.
  - `config_dialog.py`: cấu hình media type theo từng field và lưu vào config.

## 3. Data Structures
### JSON đầu vào
- Dạng chuẩn: `List[Dict]` (mỗi phần tử là 1 card object).
- Mỗi object gồm field nội dung (trùng tên field của Note Type) + optional meta keys.

### Cấu trúc `user_config.json`
- `media_fields`: mapping theo note type cho từng field (`text`/`image`/`audio`).
- `lang`: mã ngôn ngữ hiện tại (`vi`/`en`).
- `presets`: mapping `{preset_name: preset_data}`.
  - `preset_data.note_type`: note type name.
  - `preset_data.deck`: deck name.
  - `preset_data.match_field`: field dùng Smart Sync hoặc `null`.
  - `preset_data.json_text`: payload JSON thô để nạp lại nhanh.

### Meta keys đặc biệt
- `__guid__`
  - Nếu có: ưu tiên tìm note hiện có bằng SQL `select id from notes where guid = ?`.
  - Nếu tìm thấy: đi nhánh UPDATE.
- `__deck__`
  - Nếu có: dùng deck này làm đích cho card/note thay vì deck mặc định đang chọn.
  - UPDATE: di chuyển toàn bộ cards của note sang deck mới.
  - CREATE: add_note vào deck id tương ứng.
- `__tags__`
  - Chấp nhận string hoặc list.
  - String sẽ được chuẩn hóa thành list.
  - UPDATE: append tag mới nếu chưa tồn tại.
  - CREATE: gán trực tiếp `note.tags`.

### Fallback Smart Sync (`match_field`)
- Thứ tự nhận diện note:
  1. Tìm theo `__guid__` trước.
  2. Nếu không có kết quả và có `match_field` hợp lệ: fallback tìm theo giá trị field đó.
- Cơ chế:
  - Build `match_cache` trước vòng lặp: `{field_value -> note_id}` từ `SELECT id, flds FROM notes WHERE mid = ?`.
  - Parse `flds` theo delimiter `\x1f` để lấy value tại index của `match_field`.
  - Nếu card có cùng `match_field` value trong cache -> UPDATE note tương ứng.

## 4. Core Workflows
### Workflow A: Tạo/Cập nhật thẻ
1. Validate collection và lấy deck/model.
2. Nếu Note Type chưa có:
   - Nếu cards rỗng -> lỗi.
   - Nếu có sample -> tạo model mới từ keys của card đầu tiên (bỏ meta keys).
3. Tạo undo checkpoint (`mw.checkpoint`) và progress UI (`mw.progress.start/update/finish`).
4. Với mỗi card:
   - Pop meta keys: `__guid__`, `__deck__`, `__tags__`.
   - Resolve legacy `[media:...]` trong string fields.
   - Nếu có `media_mappings`: auto media download/copy cho field được đánh dấu image/audio.
   - Tìm note existing theo GUID, fallback `match_field` nếu cần.
   - UPDATE branch:
     - Chỉ ghi các key tồn tại trong note fields.
     - Unknown keys bị skip và đưa vào warnings.
     - Append tags, update note, move deck nếu có `__deck__`.
   - CREATE branch:
     - Tạo note mới từ model.
     - Gán guid nếu có.
     - Chỉ set fields hợp lệ; unknown keys -> warning.
     - Gán tags, add_note vào deck phù hợp.
5. `mw.reset()` và trả `(created_count, updated_count, warnings)`.

### Workflow B: Xử lý Media
- Legacy text mode:
  - Quét regex `\[media:(.*?)\]` trong text.
  - URL -> download; file local -> copy vào `collection.media`.
  - Trả về `<img src="...">` hoặc `[sound:...]` tùy extension.
- Field mapping mode (khuyến nghị hiện tại):
  - Mapping lấy từ `get_media_mappings(note_type_name)` trong config.
  - Với field type `image`/`audio`: gọi `smart_download_media(source, media_type, media_dir)`.
  - `smart_download_media`:
    - URL: đọc `Content-Type`, suy luận extension nếu cần.
    - Local path: copy file.
    - Luôn dùng tên unique `bulk_<uuid8>.<ext>`.
    - Trả về Anki media tag + error (nếu có) để ghi warning.

### Workflow C: Save/Load Preset
1. Người dùng chọn note type/deck/match field và nhập JSON.
2. Bấm Save Preset:
   - Validate JSON hợp lệ và là Array.
   - Nhập tên preset qua `QInputDialog`.
   - Lưu vào `user_config.json` thông qua `save_preset(...)`.
3. Bấm Load Preset:
   - Chọn preset trong combobox.
   - Nạp lại note type, deck, match field, và `json_text` vào UI.
4. Preset list luôn đọc từ `get_presets()` và refresh sau khi lưu.

### Workflow D: Sinh GUID cho JSON
1. Người dùng bấm nút Sinh GUID trong `main_dialog.py`.
2. Addon parse JSON hiện tại và chỉ tạo `__guid__` cho các object đang thiếu key này.
3. GUID sinh mới dùng `anki.utils.guid64()` và không ghi đè GUID sẵn có.
4. Mục tiêu: chuẩn bị sẵn JSON có `__guid__` trước khi import vào Anki hoặc dùng lại cho batch sau.

### Workflow E: GUID Backfill vào JSON
1. Khi batch hoàn tất, nếu tùy chọn write GUID bật, JSON input được cập nhật lại bằng dữ liệu sau xử lý.
2. `create_cards_logic(...)` viết `__guid__` vào chính object card cho cả nhánh CREATE và UPDATE.
3. Mục tiêu: người dùng có thể import lại cùng một JSON ở lần sau và Smart Sync có thể bám theo GUID.

### Workflow F: Batch History
1. Sau mỗi Create/Update thành công, addon lưu một file JSON history riêng trong folder `history/` dưới addon root.
2. Record bao gồm note type, deck, match_field, counts, warnings và payload `cards` cuối cùng.
3. UI có nút History để mở trực tiếp thư mục này trên Windows.

### Workflow G: Add Deck into JSON
1. Người dùng bấm nút "📌 Add Deck into JSON" trong `main_dialog.py`.
2. Addon parse JSON hiện tại và thêm `__deck__` cho các object đang thiếu key này.
3. `__deck__` chỉ được thêm cho object không có key này sẵn, không ghi đè `__deck__` đã tồn tại.
4. Tên deck được lấy từ deck combobox hiện tại (mặc định "Bulk Card Creator").
5. JSON được ghi ngược lại vào editor để người dùng kiểm tra.
6. Mục tiêu: chuẩn bị JSON có `__deck__` sẵn để tất cả cards sẽ import vào deck đã chọn.

### Workflow H: Help Dialog
1. Người dùng bấm nút Help ở header của `main_dialog.py`.
2. Addon mở `HelpDialog` với 2 tab English / Tiếng Việt.
3. Nội dung help mô tả toàn bộ luồng dùng và từng tính năng chính (setup, tools, JSON input, table preview, create/update).

## 5. AI Developer Guidelines (QUAN TRỌNG NHẤT)
1. Bắt buộc dùng i18n API `_t(...)` cho text hiển thị (title, message, warning); không hardcode chuỗi UI mới trực tiếp.
2. Mọi thao tác collection/deck/note phải đi qua `mw.col` (models/decks/db/note APIs), không dùng truy cập ngoài luồng Anki.
3. Khi ghi field note, luôn ép kiểu qua logic tương đương `_note_field_str` để đảm bảo giá trị lưu là string hợp lệ.
4. Không ghi bừa keys từ JSON vào note: chỉ assign key tồn tại trong note fields (`if key in note`), unknown keys phải skip + warning.
5. Luôn giữ thứ tự nhận diện note: `__guid__` trước, `match_field` fallback sau; không đảo logic này.
6. Khi sửa/tạo flow bulk, phải giữ `mw.checkpoint(...)` và `mw.progress.start/update/finish` để đảm bảo undo và UX không đơ.
7. Với media, chỉ dùng tag Anki chuẩn làm output (`<img src="...">` hoặc `[sound:...]`), không lưu raw URL trực tiếp nếu field đã mapping media.
8. UI layer (`gui/*`) chỉ điều phối/validate input và gọi core functions; business logic DB/media phải nằm ở `core.py` và `media.py`, không dồn ngược vào dialog.
9. Mọi tính năng mới có text UI phải thêm key vào cả `locales/vi.json` và `locales/en.json`; không thêm text mới mà bỏ qua i18n.
10. Preset phải lưu qua `config.py` (`get_presets`/`save_preset`) để giữ schema tập trung; không tự ghi `user_config.json` trực tiếp trong UI.
11. Nếu thêm/đổi GUID-related workflow, phải đảm bảo object JSON được backfill `__guid__` sau khi Anki tạo note mới hoặc khớp note cũ.
12. Nút Sinh GUID chỉ được lấp các object thiếu `__guid__`; không được ghi đè GUID đã tồn tại trong JSON.
13. Nếu thêm history record, phải ghi file JSON vào folder `history/` riêng thay vì nhồi vào `user_config.json`.
14. History dialog không nên tự động mở thư mục: hiển thị dialog với thông báo đường dẫn + hai nút "Open Folder History" và "Close"; cho phép user kiểm soát hành động mở folder.
15. Khi thêm Preview Mode vào table dialog, dùng `QTextBrowser` để render HTML; cung cấp toggle button để user chuyển đổi giữa Edit Mode (double-click edit) và Preview Mode (read-only, click cell hiển thị HTML preview ở panel dưới).
16. Nút "Add Deck into JSON" chỉ thêm `__deck__` cho object không có key này sẵn; không ghi đè `__deck__` đã tồn tại trong JSON.
17. Nút Help phải mở dialog hướng dẫn song ngữ (English/Tiếng Việt) để người mới có thể nắm luồng dùng mà không cần đọc code.
